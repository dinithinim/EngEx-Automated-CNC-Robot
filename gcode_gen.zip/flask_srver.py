from flask import Flask, request, jsonify
from flask_cors import CORS
import img_from_web

app = Flask(__name__)
CORS(app)

@app.route('/search', methods=['POST'])
def image_fetch():
    data = request.get_json()
    input_value = data.get('input')

    if not input_value:
        return jsonify({"status": "error", "message": "No input provided"}), 400

    try:
        result = img_from_web.main_func(input_value)   # your custom logic
        return jsonify({"status": "success", "result": result})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
