import os
import requests
import subprocess
import platform

API_KEY = "AIzaSyDZfuNNQKi625ep6NWnbD8Ty_UyeChHZXc"
CSE_ID = "511ba7e683f874473"

def google_image_search(object_name):
    query = f"simple {object_name} outline image"
    url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "key": API_KEY,
        "cx": CSE_ID,
        "searchType": "image",
        "q": query,
        "num": 1,
    }
    response = requests.get(url, params=params)
    data = response.json()
    if "items" in data:
        first_image_url = data["items"][0]["link"]
        return first_image_url
    else:
        return None

def download_image(url, save_path):
    response = requests.get(url)
    with open(save_path, "wb") as f:
        f.write(response.content)
    print(f"Image saved to: {save_path}")

def convert_image_to_gcode(image_path, output_gcode_path):
    exe_path = r"C:/Users/USER/AppData/Roaming/Python/Python311/Scripts/image2gcode.exe"
    cmd = [
        exe_path,
        "--maxpower", "300",
        "--speedmoves", "5",
        "--noise", "5",
        "--validate",
        image_path,
        output_gcode_path
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print(f"G-code generated successfully: {output_gcode_path}")
    else:
        print(f"Error generating G-code: {result.stderr}")


#if __name__ == "__main__":
def main_func(object_name):
    #object_name = input("Enter object to search sketch for: ").strip()
    image_url = google_image_search(object_name)
    if image_url:
        print(f"Found image URL: {image_url}")

        save_folder = "C:/Users/USER/Desktop/cnc_project"
        os.makedirs(save_folder, exist_ok=True)
        file_name = f"{object_name.replace(' ', '_')}_pencil_sketch.jpg"
        output_gcode_name = f"{object_name.replace(' ', '_')}_output.gcode"
        save_path = os.path.join(save_folder, file_name)

        download_image(image_url, save_path)
        convert_image_to_gcode(save_path, os.path.join(save_folder, output_gcode_name))

    else:
        print("No image found for the query.")